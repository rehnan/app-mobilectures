var ml = {};
ml.config = { url: 'https://mobilectures.herokuapp.com' };
//ml.config = { url: 'http://localhost:1337'};



/*
window.localStorage.setItem("key", "value");
var keyname = window.localStorage.key(i);
// keyname is now equal to "key"
var value = window.localStorage.getItem("key");
// value is now equal to "value"
window.localStorage.removeItem("key");
window.localStorage.setItem("key2", "value2");
window.localStorage.clear();
*/


